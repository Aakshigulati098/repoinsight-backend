package com.repoinsight.repository.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public record GithubImportRequest(

        @NotBlank(message = "GitHub URL is required")
        @Pattern(
                regexp = "^https://github\\.com/[^/\\s]+/[^/\\s]+/?$",
                message = "Provide a valid public GitHub repository URL"
        )
        String githubUrl

) {}
