package com.repoinsight.repository.service;

import com.repoinsight.repository.dto.GithubImportRequest;
import com.repoinsight.repository.dto.GithubRepositoryResponse;
import com.repoinsight.repository.entity.RepositoryInfo;
import com.repoinsight.repository.exception.RepositoryNotFoundException;
import com.repoinsight.repository.repository.RepositoryInfoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RepositoryInfoService {

    private final RepositoryInfoRepository repositoryInfoRepository;
    private final GithubClientService githubClientService;

    public RepositoryInfoService(
            RepositoryInfoRepository repositoryInfoRepository,
            GithubClientService githubClientService) {
        this.repositoryInfoRepository = repositoryInfoRepository;
        this.githubClientService = githubClientService;
    }

    public RepositoryInfo saveRepository(RepositoryInfo repositoryInfo) {
        return repositoryInfoRepository.save(repositoryInfo);
    }

    public List<RepositoryInfo> getAllRepositories() {
        return repositoryInfoRepository.findAll();
    }

    public RepositoryInfo getRepositoryById(Long id) {
        return repositoryInfoRepository.findById(id)
                .orElseThrow(() -> new RepositoryNotFoundException(id));
    }

    public RepositoryInfo updateRepository(
            Long id, RepositoryInfo updatedInfo) {

        RepositoryInfo existing = repositoryInfoRepository.findById(id)
                .orElseThrow(() -> new RepositoryNotFoundException(id));

        existing.setName(updatedInfo.getName());
        existing.setGithubUrl(updatedInfo.getGithubUrl());
        existing.setDescription(updatedInfo.getDescription());

        return repositoryInfoRepository.save(existing);
    }

    public void deleteRepository(Long id) {
        if (!repositoryInfoRepository.existsById(id)) {
            throw new RepositoryNotFoundException(id);
        }

        repositoryInfoRepository.deleteById(id);
    }

    public RepositoryInfo importFromGitHub(GithubImportRequest request) {

        GithubRepositoryResponse github =
                githubClientService.fetchRepository(request.githubUrl());

        RepositoryInfo repository = new RepositoryInfo();

        repository.setName(github.name());
        repository.setGithubUrl(github.htmlUrl());
        repository.setDescription(github.description());
        repository.setStars(github.stars());
        repository.setLanguage(github.language());
        repository.setDefaultBranch(github.defaultBranch());

        return repositoryInfoRepository.save(repository);
    }
}
