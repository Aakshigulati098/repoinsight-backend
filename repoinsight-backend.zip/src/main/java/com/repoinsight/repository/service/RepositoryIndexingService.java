
package com.repoinsight.repository.service;

import com.repoinsight.repository.entity.RepositoryInfo;
import com.repoinsight.repository.repository.RepositoryInfoRepository;
import tools.jackson.databind.JsonNode;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class RepositoryIndexingService {

    private final RepositoryInfoRepository repositoryInfoRepository;
    private final VectorStore vectorStore;
    private final RestClient githubClient;

    public RepositoryIndexingService(
            RepositoryInfoRepository repositoryInfoRepository,
            VectorStore vectorStore) {
        this.repositoryInfoRepository = repositoryInfoRepository;
        this.vectorStore = vectorStore;
        this.githubClient = RestClient.builder()
                .baseUrl("https://api.github.com")
                .defaultHeader("Accept", "application/vnd.github+json")
                .build();
    }

    public int indexRepository(Long repositoryId) {
        RepositoryInfo repository = repositoryInfoRepository
                .findById(repositoryId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Repository not found: "
                                + repositoryId));

        String[] parts = parseGitHubUrl(repository.getGithubUrl());
        String owner = parts[0];
        String repo = parts[1];
        String branch = repository.getDefaultBranch();

        if (branch == null || branch.isBlank()) {
            branch = "main";
        }

        String finalBranch = branch;

        JsonNode treeResponse = githubClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path("/repos/{owner}/{repo}/git/trees/{branch}")
                        .queryParam("recursive", "1")
                        .build(owner, repo, finalBranch))
                .retrieve()
                .body(JsonNode.class);

        if (treeResponse == null || !treeResponse.has("tree")) {
            throw new IllegalStateException("Could not fetch repository tree");
        }

        List<Document> documents = new ArrayList<>();

        for (JsonNode item : treeResponse.path("tree")) {
            if (!"blob".equals(item.path("type").asText())) {
                continue;
            }

            String path = item.path("path").asText();

            if (!isIndexable(path, item.path("size").asLong(0))) {
                continue;
            }

            try {
                String rawUrl = "https://raw.githubusercontent.com/"
                        + owner + "/" + repo + "/"
                        + finalBranch + "/" + path;

                String content = RestClient.create()
                        .get()
                        .uri(URI.create(rawUrl))
                        .retrieve()
                        .body(String.class);

                if (content == null || content.isBlank()) {
                    continue;
                }

                // Split files into overlapping chunks for retrieval.
                int chunkSize = 2500;
                int overlap = 300;

                for (int start = 0, chunkNumber = 0;
                     start < content.length();
                     start += chunkSize - overlap, chunkNumber++) {

                    int end = Math.min(start + chunkSize, content.length());
                    String chunk = content.substring(start, end);

                    documents.add(new Document(
                            chunk,
                            Map.of(
                                    "repositoryId", repositoryId,
                                    "repositoryName", repository.getName(),
                                    "filePath", path,
                                    "chunkNumber", chunkNumber
                            )
                    ));

                    if (end == content.length()) {
                        break;
                    }
                }
            } catch (Exception exception) {
                // Skip files that GitHub cannot return as text.
            }
        }

        if (documents.isEmpty()) {
            throw new IllegalStateException(
                    "No indexable source files were found.");
        }

        // Spring AI generates embeddings and writes documents to pgvector.
        vectorStore.add(documents);

        return documents.size();
    }

    private boolean isIndexable(String path, long size) {
        String lower = path.toLowerCase();

        if (size <= 0 || size > 200_000) {
            return false;
        }

        if (lower.startsWith(".git/")
                || lower.startsWith("node_modules/")
                || lower.startsWith("build/")
                || lower.startsWith("target/")
                || lower.contains("/node_modules/")) {
            return false;
        }

        return lower.endsWith(".java")
                || lower.endsWith(".js")
                || lower.endsWith(".jsx")
                || lower.endsWith(".ts")
                || lower.endsWith(".tsx")
                || lower.endsWith(".py")
                || lower.endsWith(".go")
                || lower.endsWith(".html")
                || lower.endsWith(".css")
                || lower.endsWith(".sql")
                || lower.endsWith(".xml")
                || lower.endsWith(".yml")
                || lower.endsWith(".yaml")
                || lower.endsWith(".properties")
                || lower.endsWith(".md")
                || lowerendsWithConfig(lower);
    }

    private boolean lowerendsWithConfig(String path) {
        return path.endsWith(".json")
                || path.endsWith(".gradle")
                || path.endsWith(".gradle.kts")
                || path.endsWith(".toml");
    }

    private String[] parseGitHubUrl(String githubUrl) {
        URI uri = URI.create(githubUrl);

        if (!"https".equals(uri.getScheme())
                || !"github.com".equalsIgnoreCase(uri.getHost())) {
            throw new IllegalArgumentException("Invalid GitHub URL");
        }

        String[] parts = uri.getPath()
                .replaceAll("^/|/$", "")
                .split("/");

        if (parts.length < 2) {
            throw new IllegalArgumentException("Invalid GitHub repository URL");
        }

        return new String[]{
                parts[0],
                parts[1].replaceFirst("\\.git$", "")
        };
    }
}
