package com.repoinsight.repository.controller;

import com.repoinsight.repository.service.RepositoryChatService;
import com.repoinsight.repository.service.RepositoryIndexingService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/repositories")
public class RepositoryIndexingController {

    private final RepositoryIndexingService indexingService;
    private final RepositoryChatService chatService;

    public RepositoryIndexingController(
            RepositoryIndexingService indexingService,
            RepositoryChatService chatService) {
        this.indexingService = indexingService;
        this.chatService = chatService;
    }

    @PostMapping("/{id}/index")
    public Map<String, Object> indexRepository(
            @PathVariable("id") Long id) {

        int chunks = indexingService.indexRepository(id);

        return Map.of(
                "repositoryId", id,
                "chunksIndexed", chunks,
                "message", "Repository indexed successfully"
        );
    }

    @PostMapping("/{id}/chat")
    public Map<String, Object> chat(
            @PathVariable("id") Long id,
            @RequestBody Map<String, String> request) {

        String question = request.get("question");

        if (question == null || question.isBlank()) {
            throw new IllegalArgumentException("Question is required");
        }

        return chatService.ask(id, question);
    }
}
